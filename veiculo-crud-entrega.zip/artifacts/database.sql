-- Script SQL para o banco de dados
CREATE DATABASE veiculos_db;

-- Tabelas são criadas automaticamente pelo TypeORM com synchronize: true
-- Rode este script manualmente se preferir

-- Ou use o seguinte para criar manualmente:

CREATE TABLE marcas (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE veiculos (
    id SERIAL PRIMARY KEY,
    modelo VARCHAR(100) NOT NULL,
    anoFabricacao VARCHAR(4) NOT NULL,
    anoModelo VARCHAR(4) NOT NULL,
    renavam VARCHAR(20) NOT NULL,
    placa VARCHAR(7) NOT NULL UNIQUE,
    cor VARCHAR(50) NOT NULL,
    situacao VARCHAR(20) NOT NULL CHECK (situacao IN ('liberado', 'manutencao', 'vendido')),
    marcaId INTEGER REFERENCES marcas(id)
);
