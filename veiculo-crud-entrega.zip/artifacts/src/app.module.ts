import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { MarcaModule } from './marca/marca.module';
import { VeiculoModule } from './veiculo/veiculo.module';
import { Marca } from './marca/entities/marca.entity';
import { Veiculo } from './veiculo/entities/veiculo.entity';

@Module({
  imports: [
    ConfigModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT) || 5432,
      username: process.env.DB_USERNAME || 'postgres',
      password: process.env.DB_PASSWORD || 'postgres',
      database: process.env.DB_NAME || 'veiculos_db',
      entities: [Marca, Veiculo],
      synchronize: true, // Apenas para desenvolvimento
    }),
    MarcaModule,
    VeiculoModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
