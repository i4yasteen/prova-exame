import { Controller, Get, Render } from '@nestjs/common';

@Controller()
export class AppController {
  @Get()
  @Render('inicial')
  root() {
    return { title: 'Sistema de Cadastro de Veículos' };
  }
}
