import { Controller, Get, Post, Body, Render, Redirect, Param } from '@nestjs/common';
import { MarcaService } from './marca.service';
import { CreateMarcaDto } from './dto/create-marca.dto';

@Controller('marcas')
export class MarcaController {
  constructor(private readonly marcaService: MarcaService) {}

  @Get()
  @Render('marcas/index')
  async index() {
    const marcas = await this.marcaService.findAll();
    return { marcas };
  }

  @Get('new')
  @Render('marcas/new')
  newMarca() {
    return {};
  }

  @Post()
  @Redirect('/marcas')
  async create(@Body() createMarcaDto: CreateMarcaDto) {
    await this.marcaService.create(createMarcaDto);
    return { message: 'Marca cadastrada com sucesso!' };
  }
}
