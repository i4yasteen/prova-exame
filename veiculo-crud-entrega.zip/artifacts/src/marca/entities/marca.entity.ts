import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Veiculo } from '../../veiculo/entities/veiculo.entity';

@Entity('marcas')
export class Marca {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100 })
  nome: string;

  @OneToMany(() => Veiculo, (veiculo) => veiculo.marca)
  veiculos: Veiculo[];
}
