import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Marca } from '../../marca/entities/marca.entity';

@Entity('veiculos')
export class Veiculo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100 })
  modelo: string;

  @Column({ length: 4 })
  anoFabricacao: string;

  @Column({ length: 4 })
  anoModelo: string;

  @Column({ length: 20 })
  renavam: string;

  @Column({ length: 7 })
  placa: string;

  @Column({ length: 50 })
  cor: string;

  @Column({
    type: 'enum',
    enum: ['liberado', 'manutencao', 'vendido'],
  })
  situacao: string;

  @ManyToOne(() => Marca, (marca) => marca.veiculos, { eager: true })
  marca: Marca;
}
