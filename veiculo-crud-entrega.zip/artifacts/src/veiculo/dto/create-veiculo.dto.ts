import { IsString, IsNotEmpty, Matches, MaxLength, IsEnum } from 'class-validator';

export class CreateVeiculoDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  modelo: string;

  @IsString()
  @IsNotEmpty()
  @Matches(/^\d{4}$/, { message: 'Ano de fabricação deve ter exatamente 4 dígitos' })
  anoFabricacao: string;

  @IsString()
  @IsNotEmpty()
  @Matches(/^\d{4}$/, { message: 'Ano do modelo deve ter exatamente 4 dígitos' })
  anoModelo: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(20)
  renavam: string;

  @IsString()
  @IsNotEmpty()
  @Matches(/^[A-Z0-9]{7}$/, { message: 'Placa deve ter exatamente 7 caracteres' })
  placa: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  cor: string;

  @IsEnum(['liberado', 'manutencao', 'vendido'], { message: 'Situação deve ser liberado, manutencao ou vendido' })
  situacao: string;

  @IsNotEmpty()
  marcaId: number;
}
