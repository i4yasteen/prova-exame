import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VeiculoService } from './veiculo.service';
import { VeiculoController } from './veiculo.controller';
import { Veiculo } from './entities/veiculo.entity';
import { Marca } from '../marca/entities/marca.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Veiculo, Marca])],
  controllers: [VeiculoController],
  providers: [VeiculoService],
})
export class VeiculoModule {}
