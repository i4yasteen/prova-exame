import { Controller, Get, Post, Body, Render, Redirect, Param, Delete, Put } from '@nestjs/common';
import { VeiculoService } from './veiculo.service';
import { CreateVeiculoDto } from './dto/create-veiculo.dto';
import { MarcaService } from '../marca/marca.service';

@Controller('veiculos')
export class VeiculoController {
  constructor(
    private readonly veiculoService: VeiculoService,
    private readonly marcaService: MarcaService,
  ) {}

  @Get()
  @Render('veiculos/index')
  async index() {
    const veiculos = await this.veiculoService.findAll();
    return { veiculos };
  }

  @Get('new')
  @Render('veiculos/new')
  async newVeiculo() {
    const marcas = await this.marcaService.findAll();
    return { marcas };
  }

  @Post()
  @Redirect('/veiculos')
  async create(@Body() createVeiculoDto: CreateVeiculoDto) {
    await this.veiculoService.create(createVeiculoDto);
    return { message: 'Veículo cadastrado com sucesso!' };
  }

  @Get(':id/edit')
  @Render('veiculos/edit')
  async edit(@Param('id') id: number) {
    const veiculo = await this.veiculoService.findOne(id);
    const marcas = await this.marcaService.findAll();
    return { veiculo, marcas };
  }

  @Put(':id')
  @Redirect('/veiculos')
  async update(@Param('id') id: number, @Body() updateData: any) {
    await this.veiculoService.update(id, updateData);
    return { message: 'Veículo atualizado com sucesso!' };
  }

  @Delete(':id')
  @Redirect('/veiculos')
  async remove(@Param('id') id: number) {
    await this.veiculoService.remove(id);
    return { message: 'Veículo removido com sucesso!' };
  }
}
