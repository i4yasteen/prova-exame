import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Veiculo } from './entities/veiculo.entity';
import { CreateVeiculoDto } from './dto/create-veiculo.dto';
import { Marca } from '../marca/entities/marca.entity';

@Injectable()
export class VeiculoService {
  constructor(
    @InjectRepository(Veiculo)
    private veiculoRepository: Repository<Veiculo>,
    @InjectRepository(Marca)
    private marcaRepository: Repository<Marca>,
  ) {}

  async create(createVeiculoDto: CreateVeiculoDto): Promise<Veiculo> {
    const marca = await this.marcaRepository.findOne({
      where: { id: createVeiculoDto.marcaId },
    });

    if (!marca) {
      throw new NotFoundException('Marca não encontrada');
    }

    const veiculo = this.veiculoRepository.create({
      ...createVeiculoDto,
      marca,
    });

    return this.veiculoRepository.save(veiculo);
  }

  async findAll(): Promise<Veiculo[]> {
    return this.veiculoRepository.find({ relations: ['marca'] });
  }

  async findOne(id: number): Promise<Veiculo> {
    const veiculo = await this.veiculoRepository.findOne({
      where: { id },
      relations: ['marca'],
    });
    if (!veiculo) {
      throw new NotFoundException(`Veículo #${id} não encontrado`);
    }
    return veiculo;
  }

  async update(id: number, updateData: Partial<Veiculo>) {
    await this.findOne(id);
    return this.veiculoRepository.update(id, updateData);
  }

  async remove(id: number) {
    await this.findOne(id);
    return this.veiculoRepository.delete(id);
  }
}
